#include <stdio.h>
void CONTADOR(int v[], int x);
void PREENCHE(int v[], int y);
struct contadores{
    int cont0, cont1, cont2, cont3, cont4, cont5, cont6, cont7, cont8, cont9;
};

int N,M,i;
struct contadores p1;

void main(void){
    p1.cont0 = 0, p1.cont1 = 0, p1.cont2 = 0, p1.cont3 = 0, p1.cont4 = 0, p1.cont5 = 0, p1.cont6 = 0, p1.cont7 = 0, p1.cont8 = 0, p1.cont9 = 0;

    scanf("%d %d", &N, &M);
    
    int v1[N], v2[M];
    
    //N inteiros entre 0 e 9;
    PREENCHE(v1,N);
    //Inteiros M que representam a sequ�ncia de posi��es que o propriet�rio seguir�;
    PREENCHE(v2,M);
    
    int j, cond;
    v2[1] = 1;
    
   	j = v2[1];
   	
   	CONTADOR(v1,j);
   	
	i = 1;	
	//Este while ir� verificar todas as posi��es digitadas no vetor M;
	while(i<M){
		//Analisar se existe posi��es iguais
		if(v2[i] == v2[i+1]) break;
		
		if(v2[i]>v2[i+1]){
			/*Cond ser� uma condi��o para contagem pois na logica da quest�o o valor da posi��o de inicio
		    n�o ser� contabilizado*/
		    
		    /*Valor de Cond ser� sempre 0, pois quando entra dentro do while, ser�
			testado a condi��o de contagem e como o primeiro valor do inicio da contagem
			n�o s�ra contado, ent�o ele ser� pulado*/
			cond = 0;
			j = v2[i];
			while(j>=v2[i+1]){
				if(cond == 1) CONTADOR(v1,j);
				/*aqui tamb�m ter� valor fixo, pois como j� foi pulado o primeiro valor
				o restante ter� que ser contabilizado*/
				cond = 1;
				j--;
			}
		}else{
			cond = 0;
			j = v2[i];
			while(j<=v2[i+1]){
				if(cond == 1) CONTADOR(v1,j);
				
				cond = 1;
				j++;
			}	
		}
		i++;
	}
    
    printf("%d %d %d %d %d %d %d %d %d %d", p1.cont0, p1.cont1, p1.cont2, p1.cont3, p1.cont4, p1.cont5, p1.cont6, p1.cont7, p1.cont8, p1.cont9);
    
}
void PREENCHE(int v[], int y){
    for(i=1;i<=y;i++) scanf("%d", &v[i]);
}

void CONTADOR(int v[], int x){
    
        if(v[x] == 0) p1.cont0++;
                
        if(v[x] == 1) p1.cont1++;
                
        if(v[x] == 2) p1.cont2++;
                
        if(v[x] == 3) p1.cont3++;
                
        if(v[x] == 4) p1.cont4++;
                
        if(v[x] == 5) p1.cont5++;
                
        if(v[x] == 6) p1.cont6++;
                
        if(v[x] == 7) p1.cont7++;
                
        if(v[x] == 8) p1.cont8++;
                
        if(v[x] == 9) p1.cont9++;  
}
